using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json.Linq;
using UnityEngine;
using UnityEngine.UIElements;

namespace MrMak.UIImport
{
    // Explicit adapter for the installed GE presentation builders. No match actions are called.
    internal static class GEImportProfiles
    {
        internal sealed class Profile {public VisualElement Root;public string Id,Name;public Action Dispose;public Action<JObject,Dictionary<VisualElement,string>> Configure;}
        const BindingFlags Flags=BindingFlags.Instance|BindingFlags.NonPublic|BindingFlags.Public;
        public static bool IsGE(UIDocument document)=>document.GetComponentInParent<MonoBehaviour>()?.GetType().FullName=="GlobalEmpires.View.GameHud"||document.GetComponentsInParent<MonoBehaviour>().Any(c=>c!=null&&c.GetType().FullName=="GlobalEmpires.View.GameHud");
        public static IEnumerable<Profile> Build(UIDocument document,Action<string> report) {
            var hud=document.GetComponentsInParent<MonoBehaviour>().FirstOrDefault(c=>c!=null&&c.GetType().FullName=="GlobalEmpires.View.GameHud");if(hud==null)yield break;
            var type=hud.GetType();var root=(VisualElement)type.GetField("root",Flags).GetValue(hud);var layer=(VisualElement)type.GetField("hudLayer",Flags).GetValue(hud);
            if(layer.layout.width>0&&layer.layout.height>0){
                var card=(VisualElement)type.GetField("card",Flags).GetValue(hud);var children=card.Children().ToArray();var display=card.style.display;var enabled=hud.enabled;
                var fixtures=new List<VisualElement>();
                var grid=(VisualElement)type.GetField("gridPanel",Flags).GetValue(hud);var gridParent=grid.parent;var gridIndex=gridParent.IndexOf(grid);VisualElement commandPreview=null;var commandFixture=false;
                Action restore=()=>{commandPreview?.RemoveFromHierarchy();if(grid.parent==null)gridParent.Insert(Math.Min(gridIndex,gridParent.childCount),grid);card.Clear();foreach(var child in children)card.Add(child);card.style.display=display;hud.enabled=enabled;};
                try{
                    // Freeze presentation for a few layout frames. These are native CardModel
                    // fixtures; no selection, training or match command is executed.
                    hud.enabled=false;card.Clear();card.style.display=DisplayStyle.Flex;
                    foreach(var kind in new[]{"Unit","Group","Building"}){
                        var variant=new VisualElement{name="selection-"+kind,viewDataKey="ge.selection."+kind};variant.style.position=Position.Absolute;variant.style.left=variant.style.top=0;variant.style.width=variant.style.height=Length.Percent(100);card.Add(variant);fixtures.Add(variant);
                        var modelType=type.GetField("cardModel",Flags).FieldType;var model=Activator.CreateInstance(modelType);Action<string,object> set=(key,value)=>modelType.GetField(key).SetValue(model,value);
                        var entityType=modelType.GetField("Type").FieldType;var worker=Enum.Parse(entityType,"Worker");
                        set("Kind",Enum.Parse(modelType.GetField("Kind").FieldType,kind));set("Type",worker);set("Title",kind=="Group"?"Unidades selecionadas":kind=="Building"?"Centro urbano":"Trabalhador");set("Health",100);set("MaxHealth",100);
                        if(kind=="Group"){var list=(IList)modelType.GetField("Tiles").GetValue(model);var tileType=list.GetType().GetGenericArguments()[0];var tile=Activator.CreateInstance(tileType);foreach(var pair in new[]{("Type",(object)worker),("Name","Trabalhador"),("Count",1),("Health",100),("MaxHealth",100),("FirstId",1)})tileType.GetField(pair.Item1).SetValue(tile,pair.Item2);list.Add(tile);}
                        if(kind=="Building"){var list=(IList)modelType.GetField("Queue").GetValue(model);var queueType=list.GetType().GetGenericArguments()[0];list.Add(Activator.CreateInstance(queueType,new object[]{worker,"Trabalhador","Em treinamento",.35f}));}
                        type.GetField("card",Flags).SetValue(hud,variant);try{type.GetMethod(kind=="Group"?"GroupCard":"SingleCard",Flags).Invoke(hud,new[]{model});}finally{type.GetField("card",Flags).SetValue(hud,card);}
                    }
                    commandFixture=grid.resolvedStyle.display==DisplayStyle.None||!(grid.layout.width>0&&grid.layout.height>0);
                    commandPreview=BuildCommandPreview(hud,grid,commandFixture);grid.RemoveFromHierarchy();gridParent.Insert(gridIndex,commandPreview);
                }catch{restore();throw;}
                yield return new Profile{Root=layer,Id="ge.hud",Name="GE - HUD and selection templates",Configure=(entry,map)=>{
                    var slots=commandPreview.Children().Where(e=>e.ClassListContains("ge-row")).SelectMany(e=>e.Children()).ToArray();
                    if(!(commandPreview.layout.width>0&&commandPreview.layout.height>0&&slots.Length==15&&slots.All(e=>e.layout.width>0&&e.layout.height>0)))throw new InvalidOperationException("GE command preview has no usable layout. Wait for the game HUD to finish laying out, then export again.");
                    ConfigureHUD(hud,entry,map,fixtures);((JArray)entry["origins"][0]["notes"]).Add(commandFixture?"Hidden command panel: declared worker command presentation fixture, built by native CommandGrid.Fill/Show without selecting units or executing actions. Slots remain a static snapshot; dynamic command bindings are not imported.":"Visible command panel: current native command cells retained as a static snapshot; dynamic command bindings are not imported.");
                },Dispose=restore};
            }
            foreach(var spec in new[]{("ge.start","GE - Main menu","StartScreen",false),("ge.start-options","GE - Menu options","StartScreen",true),("ge.pause","GE - Pause","PauseScreen",false),("ge.pause-options","GE - Pause options","PauseScreen",true),("ge.ended","GE - End summary (current match)","EndScreen",false)}) {
                var fields=type.GetFields(Flags);var values=fields.ToDictionary(f=>f,f=>f.GetValue(hud));var arrays=fields.Where(f=>f.GetValue(hud) is Array).ToDictionary(f=>f,f=>(Array)((Array)f.GetValue(hud)).Clone());
                var lists=fields.Where(f=>f.GetValue(hud) is IList&&!(f.GetValue(hud) is Array)).ToDictionary(f=>f,f=>((IList)f.GetValue(hud)).Cast<object>().ToArray());
                var flow=type.GetField("flow",Flags).GetValue(hud);var options=flow?.GetType().GetProperty("OptionsOpen",Flags);var originalOptions=options?.GetValue(flow);var random=UnityEngine.Random.state;
                var preview=new VisualElement{name="import-profile-"+spec.Item1,pickingMode=PickingMode.Ignore};preview.AddToClassList("ge-screens");if(spec.Item1.StartsWith("ge.start"))preview.AddToClassList("ge-screens--start");preview.style.position=Position.Absolute;preview.style.left=preview.style.top=0;preview.style.width=root.layout.width;preview.style.height=root.layout.height;preview.style.opacity=0;preview.style.unityFontDefinition=root.resolvedStyle.unityFontDefinition;root.Add(preview);
                Exception failure=null;
                try{options?.SetValue(flow,spec.Item4);type.GetField("screenLayer",Flags).SetValue(hud,preview);type.GetMethod(spec.Item3,Flags).Invoke(hud,null);}
                catch(Exception e){failure=e;}
                finally{
                    foreach(var f in fields)if(!f.IsInitOnly)f.SetValue(hud,values[f]);
                    foreach(var a in arrays)Array.Copy(a.Value,(Array)values[a.Key],a.Value.Length);
                    foreach(var l in lists){var list=(IList)values[l.Key];list.Clear();foreach(var item in l.Value)list.Add(item);}
                    options?.SetValue(flow,originalOptions);UnityEngine.Random.state=random;
                }
                if(failure!=null){preview.RemoveFromHierarchy();report("UI import profile not observed: "+spec.Item2+" - "+failure.GetBaseException().Message);continue;}
                yield return new Profile{Root=preview,Id=spec.Item1,Name=spec.Item2,Dispose=()=>preview.RemoveFromHierarchy()};
            }
        }
        // Build a temporary native view instead of changing the game's original cells,
        // labels or visibility. All private renderer fields/arrays are restored before
        // the exporter awaits layout; only this detached view is captured and removed.
        static VisualElement BuildCommandPreview(MonoBehaviour hud,VisualElement source,bool fixture){
            var type=hud.GetType();var fields=new[]{"gridPanel","gridTitle","hovered","pressed","cells","shown","applied","views"}.Select(name=>type.GetField(name,Flags)).ToArray();
            var values=fields.ToDictionary(f=>f,f=>f.GetValue(hud));var arrays=fields.Where(f=>values[f] is Array).ToDictionary(f=>f,f=>(Array)((Array)values[f]).Clone());
            var preview=new VisualElement{name=source.name,viewDataKey=source.viewDataKey};foreach(var c in source.GetClasses())preview.AddToClassList(c);
            preview.style.position=Position.Absolute;preview.style.display=DisplayStyle.Flex;
            preview.style.left=source.style.left;preview.style.top=source.style.top;preview.style.right=source.style.right;preview.style.bottom=source.style.bottom;preview.style.width=source.style.width;preview.style.height=source.style.height;
            if(source.style.width.value.value<=0||source.style.height.value.value<=0){
                Func<string,float> native=name=>Convert.ToSingle(type.GetField(name,BindingFlags.Static|BindingFlags.NonPublic).GetRawConstantValue());
                preview.style.left=native("CardLeft")+native("CardWidth")-1;preview.style.right=StyleKeyword.Auto;preview.style.top=StyleKeyword.Auto;preview.style.bottom=Convert.ToSingle(type.GetField("gridBottom",Flags).GetValue(hud));preview.style.width=native("GridWidth");preview.style.height=native("BottomHeight");
            }
            var originalTitle=(Label)type.GetField("gridTitle",Flags).GetValue(hud);var title=new Label(fixture?"Trabalhador":originalTitle.text);foreach(var c in originalTitle.GetClasses())title.AddToClassList(c);preview.Add(title);
            try{
                type.GetField("gridPanel",Flags).SetValue(hud,preview);type.GetField("gridTitle",Flags).SetValue(hud,title);type.GetField("hovered",Flags).SetValue(hud,-1);type.GetField("pressed",Flags).SetValue(hud,-1);
                var cells=(Array)type.GetField("cells",Flags).GetValue(hud);var count=cells.Length;var gridType=cells.GetType().GetElementType().Assembly.GetType("GlobalEmpires.View.CommandGrid");
                if(fixture){
                    var runner=type.GetField("runner",Flags).GetValue(hud);var session=runner?.GetType().GetProperty("Session").GetValue(runner);var world=session?.GetType().GetProperty("World").GetValue(session);if(world==null)throw new InvalidOperationException("A live GE world is required for the worker command presentation fixture.");
                    var fill=gridType.GetMethod("Fill",BindingFlags.Static|BindingFlags.Public);var args=fill.GetParameters();var player=type.Assembly.GetType("GlobalEmpires.View.PrototypeBootstrap").GetProperty("LocalPlayer",BindingFlags.Static|BindingFlags.Public).GetValue(null);
                    fill.Invoke(null,new object[]{cells,world,player,Array.Empty<int>(),Enum.Parse(args[4].ParameterType,"Workers"),0,Enum.Parse(args[6].ParameterType,"None"),false});
                }
                var applied=(Array)type.GetField("applied",Flags).GetValue(hud);Array.Clear(applied,0,applied.Length);
                var columns=(int)gridType.GetField("Columns",BindingFlags.Static|BindingFlags.Public).GetValue(null);var make=type.GetMethod("MakeCell",Flags,null,new[]{typeof(int)},null);var show=type.GetMethod("Show",Flags,null,new[]{typeof(int)},null);
                for(var slot=0;slot<count;slot++){
                    if(slot%columns==0){var row=new VisualElement();row.AddToClassList("ge-row");preview.Add(row);}
                    preview[preview.childCount-1].Add((VisualElement)make.Invoke(hud,new object[]{slot}));show.Invoke(hud,new object[]{slot});
                }
                return preview;
            }finally{
                foreach(var pair in arrays)Array.Copy(pair.Value,(Array)values[pair.Key],pair.Value.Length);
                foreach(var field in fields)if(!field.IsInitOnly)field.SetValue(hud,values[field]);
            }
        }
        static JObject Expression(string type,string key)=>new JObject{["type"]=type,["key"]=key};
        static JObject Binding(string id)=>new JObject{["target"]=new JObject{["kind"]="node",["id"]=id},["text"]=null,["tooltip"]=null,["progress"]=null,["repeat"]=null,["visible"]=new JObject{["mode"]="all",["items"]=new JArray()},["enabled"]=new JObject{["mode"]="all",["items"]=new JArray()}};
        static void Condition(JObject binding,string property,string type,string key,object value){((JArray)binding[property]["items"]).Add(new JObject{["left"]=Expression(type,key),["op"]="eq",["right"]=new JObject{["type"]="literal",["value"]=JToken.FromObject(value)}});}
        static void ConfigureHUD(MonoBehaviour hud,JObject entry,Dictionary<VisualElement,string> map,List<VisualElement> fixtures){
            var behavior=(JObject)entry["document"]["behavior"];var bindings=(JArray)behavior["bindings"];var rules=(JArray)behavior["rules"];var type=hud.GetType();
            foreach(var name in new[]{"food","wood","metal","money"}){var e=(VisualElement)type.GetField(name,Flags).GetValue(hud);if(map.TryGetValue(e,out var id)){var b=Binding(id);b["text"]=Expression("data","ge.economy."+name);bindings.Add(b);}}
            foreach(var fixture in fixtures){var kind=fixture.name.Substring("selection-".Length);var b=Binding(map[fixture]);Condition(b,"visible","data","ge.selection.kind",kind);bindings.Add(b);}
            foreach(var pair in map){var e=pair.Key;var b=Binding(pair.Value);var used=false;
                if(e.ClassListContains("ge-card-title")){b["text"]=Expression("data","ge.selection.title");used=true;}
                var tile=e.ClassListContains("ge-tile")||e.ClassListContains("ge-tile--grouped");var queue=e.ClassListContains("ge-queue-item");
                if(tile||queue){var collection=tile?"ge.selection.items":"ge.queue.items";b["repeat"]=new JObject{["collection"]=collection,["axis"]="horizontal",["gap"]=6};b["tooltip"]=Expression("item","detail");b["progress"]=Expression("item","progress");used=true;var interaction=pair.Value+"-click";if(((JArray)entry["document"]["nodes"]).Any(n=>(string)n["id"]==interaction)){var rule=new JObject{["id"]="action-"+UIProjectExporter.Key(pair.Value).Substring(0,20),["name"]=tile?"Focus selection item":"Cancel queue item",["target"]=new JObject{["kind"]="node",["id"]=interaction},["event"]="click",["conditions"]=new JObject{["mode"]="all",["items"]=new JArray()},["effects"]=new JArray(new JObject{["type"]="dispatch",["bindingId"]=tile?"ge.selection.focus":"ge.queue.cancel",["intent"]=""})};rules.Add(rule);}}
                if(e.ClassListContains("ge-tile-name")){b["text"]=Expression("item","label");used=true;}
                if(e.ClassListContains("ge-tile-count")){b["text"]=Expression("item","count");used=true;}
                if(e.ClassListContains("ge-health-text")){var ancestor=e.parent;while(ancestor!=null&&!ancestor.ClassListContains("ge-tile")&&!ancestor.ClassListContains("ge-tile--grouped"))ancestor=ancestor.parent;b["text"]=Expression(ancestor==null?"data":"item",ancestor==null?"ge.selection.health":"health");used=true;}
                if(used)bindings.Add(b);
            }
            var rootNotes=(JArray)entry["origins"][0]["notes"];rootNotes.Add("Declared CardModel fixtures for unit/group/building use native presentation builders. Resource values and selection/queue collections are simulated from the existing GE catalog; command art remains an observed grid snapshot.");
            var frame=(VisualElement)type.GetField("minimapFrame",Flags).GetValue(hud);if(map.TryGetValue(frame,out var frameId)){var origin=((JArray)entry["origins"]).First(o=>(string)o["nodeId"]==frameId);origin["coverage"]="native";((JArray)origin["notes"]).Add("The editable minimap frame is captured. The custom game renderer stays native and is not reproduced by this import.");}
        }
    }
}
