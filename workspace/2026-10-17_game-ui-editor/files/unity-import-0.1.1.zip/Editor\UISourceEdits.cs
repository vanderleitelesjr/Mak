using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace MrMak.UIImport
{
    // A small source-property writer. It never replaces GameObjects, references,
    // components, listeners, scripts, or prefab hierarchy.
    public static class UISourceEdits
    {
        static void Require(bool value,string message){if(!value)throw new InvalidOperationException(message);}
        static bool Same(JToken a,JToken b)=>a!=null&&b!=null&&a.Type!=JTokenType.Null&&b.Type!=JTokenType.Null&&((a.Type==JTokenType.Integer||a.Type==JTokenType.Float)&&(b.Type==JTokenType.Integer||b.Type==JTokenType.Float)?(double)a==(double)b:JToken.DeepEquals(a,b));
        static void Keys(JObject value,params string[] names)=>Require(value!=null&&value.Properties().Select(p=>p.Name).OrderBy(p=>p,StringComparer.Ordinal).SequenceEqual(names.OrderBy(p=>p,StringComparer.Ordinal)),"Unexpected source edit fields.");
        static JObject Read(string file){UIProjectExporter.SafeProjectPath(file);var info=new FileInfo(file);Require(info.Length<=16*1024*1024,"Source review exceeds 16 MB.");using(var reader=new Newtonsoft.Json.JsonTextReader(new StringReader(File.ReadAllText(file))){MaxDepth=48,DateParseHandling=Newtonsoft.Json.DateParseHandling.None}){var result=JObject.Load(reader,new Newtonsoft.Json.Linq.JsonLoadSettings{DuplicatePropertyNameHandling=DuplicatePropertyNameHandling.Error});Require(!reader.Read(),"Extra source review content.");return result;}}
        static Color ParseColor(string value){Require(value!=null&&Regex.IsMatch(value,"^#[0-9a-fA-F]{8}$"),"Source color must be #RRGGBBAA.");ColorUtility.TryParseHtmlString(value,out var color);return color;}
        static IEnumerable<string> Declarations(string css){var start=0;var depth=0;var quote='\0';var escaped=false;for(var i=0;i<css.Length;i++){var c=css[i];if(escaped){escaped=false;continue;}if(c=='\\'){escaped=true;continue;}if(quote!='\0'){if(c==quote)quote='\0';continue;}if(c=='\''||c=='"'){quote=c;continue;}if(c=='(')depth++;else if(c==')')depth=Math.Max(0,depth-1);else if(c==';'&&depth==0){yield return css.Substring(start,i-start);start=i+1;}}yield return css.Substring(start);}
        sealed class Mutation{public SerializedObject Object;public string Property;public JToken After;}
        [MenuItem("Tools/Game UI Editor/Review Source Edits")]
        public static void Menu(){try{var count=ApplyReviewedEdits();if(count>0)EditorUtility.DisplayDialog("Source edits applied",count+" properties saved. Export Existing UI and reimport to update the baseline.","OK");}catch(Exception e){Debug.LogException(e);EditorUtility.DisplayDialog("Source edits refused",e.Message,"OK");}}
        public static int ApplyReviewedEdits(bool showDialog=true)
        {
            var prefabContents=new Dictionary<string,GameObject>();
            try{return Apply(showDialog,prefabContents);}
            finally{foreach(var root in prefabContents.Values)PrefabUtility.UnloadPrefabContents(root);}
        }
        static int Apply(bool showDialog,Dictionary<string,GameObject> prefabContents)
        {
            Require(!EditorApplication.isPlayingOrWillChangePlaymode,"Leave Play mode before applying persistent source edits.");
            var folder=UIProjectExporter.ExportFolder;var review=Read(Path.Combine(folder,"reviewed-edits.json"));Keys(review,"version","sourceId","manifestHash","changes");
            Require((int?)review["version"]==1&&(string)review["sourceId"]==UIProjectExporter.Key(PlayerSettings.productGUID.ToString()),"This review belongs to another Unity project.");
            var manifestFile=Path.Combine(folder,"manifest.json");var manifest=Read(manifestFile);Require(UIProjectExporter.Hash(File.ReadAllBytes(manifestFile))==(string)review["manifestHash"],"The UI export changed after review. Reimport and compare again.");
            var edits=review["changes"] as JArray;Require(edits!=null&&edits.Count>0&&edits.Count<=2000,"Invalid source property count.");
            var mutations=new List<Mutation>();var xml=new Dictionary<string,XDocument>(StringComparer.Ordinal);var files=new Dictionary<string,byte[]>(StringComparer.Ordinal);var scenes=new Dictionary<string,Scene>();var prefabs=new HashSet<GameObject>();var seen=new HashSet<string>();
            foreach(var token in edits){
                var edit=token as JObject;Keys(edit,"entryId","key","name","field","before","after");var field=(string)edit["field"];Require(new[]{"text","style.color","style.background","style.fontSize"}.Contains(field),"Unsupported source property.");Require(seen.Add((string)edit["entryId"]+":"+(string)edit["key"]+":"+field),"Duplicate source property edit.");
                var entry=((JArray)manifest["entries"]).FirstOrDefault(e=>(string)e["id"]==(string)edit["entryId"]);Require(entry!=null&&entry["source"]!=null,"This source has no persistent property writer.");var origin=((JArray)entry["origins"]).FirstOrDefault(o=>(string)o["key"]==(string)edit["key"]);Require(origin!=null,"Source identity is missing.");var node=((JArray)entry["document"]["nodes"]).First(n=>(string)n["id"]==(string)origin["nodeId"]);var before=field=="text"?node["text"]:node["style"][field.Substring(6)];Require(Same(before,edit["before"]),"Source property baseline changed.");
                if(field=="text")Require(edit["after"].Type==JTokenType.String&&((string)edit["after"]).Length<=4096&&!Regex.IsMatch((string)edit["after"],"[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]"),"Invalid source text.");else if(field=="style.fontSize")Require((edit["after"].Type==JTokenType.Integer||edit["after"].Type==JTokenType.Float)&&(double)edit["after"]>=1&&(double)edit["after"]<=512,"Invalid source font size.");else ParseColor((string)edit["after"]);
                var assetPath=AssetDatabase.GUIDToAssetPath((string)entry["source"]["guid"]);Require(assetPath.StartsWith("Assets/",StringComparison.Ordinal)&&File.Exists(assetPath),"Source must be an existing project asset.");UIProjectExporter.SafeProjectPath(Path.GetFullPath(assetPath));var bytes=File.ReadAllBytes(assetPath);Require(UIProjectExporter.Hash(bytes)==(string)entry["source"]["sha256"],"Source file changed since export: "+assetPath);files[assetPath]=bytes;
                if((string)entry["source"]["kind"]=="uxml"){
                    Require(assetPath.EndsWith(".uxml",StringComparison.OrdinalIgnoreCase)&&((string)edit["key"]).StartsWith("viewDataKey:",StringComparison.Ordinal),"A persistent UXML viewDataKey is required.");
                    if(!xml.TryGetValue(assetPath,out var document)){using(var reader=XmlReader.Create(new StringReader(Encoding.UTF8.GetString(bytes).TrimStart('\uFEFF')),new XmlReaderSettings{DtdProcessing=DtdProcessing.Prohibit,XmlResolver=null}))document=XDocument.Load(reader,LoadOptions.PreserveWhitespace);xml[assetPath]=document;}
                    var key=((string)edit["key"]).Substring("viewDataKey:".Length);var elements=document.Descendants().Where(e=>(string)e.Attribute("view-data-key")==key).ToArray();Require(elements.Length==1,"UXML viewDataKey is missing or ambiguous.");var element=elements[0];
                    if(field=="text")element.SetAttributeValue("text",(string)edit["after"]);else{var property=field=="style.color"?"color":field=="style.background"?"background-color":"font-size";var declarations=Declarations((string)element.Attribute("style")??"").Where(v=>!Regex.IsMatch(v,"^\\s*"+property+"\\s*:",RegexOptions.IgnoreCase)&&!string.IsNullOrWhiteSpace(v)).ToList();declarations.Add(property+":"+(field=="style.fontSize"?((double)edit["after"]).ToString(System.Globalization.CultureInfo.InvariantCulture)+"px":(string)edit["after"]));element.SetAttributeValue("style",string.Join(";",declarations)+";");}
                }else{
                    var validId=GlobalObjectId.TryParse((string)edit["key"],out var objectId);Require((string)entry["system"]=="ugui"&&validId,"Only persistent uGUI controls can use this writer.");Transform transform;
                    if((string)entry["source"]["kind"]=="prefab"){Require(assetPath.EndsWith(".prefab",StringComparison.OrdinalIgnoreCase),"Invalid prefab source.");if(!prefabContents.TryGetValue(assetPath,out var contents)){contents=PrefabUtility.LoadPrefabContents(assetPath);prefabContents[assetPath]=contents;}transform=contents.GetComponentsInChildren<Transform>(true).FirstOrDefault(t=>GlobalObjectId.GetGlobalObjectIdSlow(t).ToString()==(string)edit["key"]);}
                    else transform=GlobalObjectId.GlobalObjectIdentifierToObjectSlow(objectId) as Transform;Require(transform!=null,"Open the original scene before reviewing source edits; prefab identity must match its source asset.");
                    var text=transform.GetComponents<Component>().FirstOrDefault(c=>c!=null&&(c.GetType().FullName=="UnityEngine.UI.Text"||c.GetType().FullName=="TMPro.TextMeshProUGUI"));Require(text!=null&&field!="style.background","The uGUI writer supports text controls only.");var serialized=new SerializedObject(text);var property=field=="text"?(serialized.FindProperty("m_Text")??serialized.FindProperty("m_text")):field=="style.fontSize"?(serialized.FindProperty("m_FontData.m_FontSize")??serialized.FindProperty("m_fontSize")):(serialized.FindProperty("m_Color")??serialized.FindProperty("m_fontColor"));Require(property!=null,"Source property is unavailable in this uGUI version.");
                    var actual=property.propertyType==SerializedPropertyType.String?new JValue(property.stringValue):property.propertyType==SerializedPropertyType.Color?new JValue("#"+ColorUtility.ToHtmlStringRGBA(property.colorValue)):property.propertyType==SerializedPropertyType.Integer?new JValue(property.intValue):new JValue(property.floatValue);Require(Same(actual,edit["before"]),"The live source property changed since export: "+(string)edit["name"]);
                    if(property.propertyType==SerializedPropertyType.Integer)Require(Math.Floor((double)edit["after"])==(double)edit["after"],"Legacy Text font size must be an integer.");
                    if((string)entry["source"]["kind"]!="prefab"){if(EditorUtility.IsPersistent(text)){var root=transform.root.gameObject;Require(PrefabUtility.IsPartOfPrefabAsset(root),"Unsupported persistent UI object.");prefabs.Add(root);}else{var scene=text.gameObject.scene;Require(scene.IsValid()&&scene.path==assetPath&&!scene.isDirty,"Save/reload the original scene before applying source edits.");scenes[scene.path]=scene;}}
                    mutations.Add(new Mutation{Object=serialized,Property=property.propertyPath,After=edit["after"].DeepClone()});
                }
            }
            if(showDialog&&!EditorUtility.DisplayDialog("Review existing UI source edits",edits.Count+" properties in "+files.Count+" source files.\n\n"+string.Join("\n",edits.Take(15).Select(e=>(string)e["name"]+" · "+(string)e["field"]))+"\n\nBackups will be kept under .local/game-ui-export/source-backups. Original callbacks and hierarchy are preserved.","Apply reviewed properties","Cancel"))return 0;
            foreach(var file in files){UIProjectExporter.SafeProjectPath(Path.GetFullPath(file.Key));Require(UIProjectExporter.Hash(File.ReadAllBytes(file.Key))==UIProjectExporter.Hash(file.Value),"Source changed during review. Compare again.");}
            var backup=Path.Combine(folder,"source-backups",DateTime.UtcNow.ToString("yyyyMMddTHHmmssfff")+"-"+Guid.NewGuid().ToString("N"));UIProjectExporter.SafeProjectPath(backup);Directory.CreateDirectory(backup);foreach(var file in files)File.WriteAllBytes(Path.Combine(backup,UIProjectExporter.Key(file.Key)+Path.GetExtension(file.Key)),file.Value);
            Undo.IncrementCurrentGroup();var undo=Undo.GetCurrentGroup();Undo.SetCurrentGroupName("Game UI Editor source properties");
            try{
                foreach(var mutation in mutations){Undo.RecordObject(mutation.Object.targetObject,"Game UI Editor source properties");mutation.Object.Update();var p=mutation.Object.FindProperty(mutation.Property);if(p.propertyType==SerializedPropertyType.String)p.stringValue=(string)mutation.After;else if(p.propertyType==SerializedPropertyType.Color)p.colorValue=ParseColor((string)mutation.After);else if(p.propertyType==SerializedPropertyType.Integer)p.intValue=(int)mutation.After;else p.floatValue=(float)mutation.After;mutation.Object.ApplyModifiedProperties();EditorUtility.SetDirty(mutation.Object.targetObject);}
                foreach(var document in xml){var temp=document.Key+"."+Guid.NewGuid().ToString("N")+".tmp";UIProjectExporter.SafeProjectPath(Path.GetFullPath(temp));document.Value.Save(temp,SaveOptions.DisableFormatting);File.Replace(temp,document.Key,null);}
                foreach(var prefab in prefabContents){var saved=PrefabUtility.SaveAsPrefabAsset(prefab.Value,prefab.Key,out var success);Require(success&&saved!=null,"Could not save source prefab.");}foreach(var root in prefabs)Require(PrefabUtility.SavePrefabAsset(root)!=null,"Could not save source prefab.");foreach(var scene in scenes.Values)Require(EditorSceneManager.SaveScene(scene),"Could not save source scene.");
                AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);Undo.CollapseUndoOperations(undo);return edits.Count;
            }catch{Undo.RevertAllDownToGroup(undo);foreach(var file in files)File.WriteAllBytes(file.Key,file.Value);AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);throw;}
        }
    }
}
