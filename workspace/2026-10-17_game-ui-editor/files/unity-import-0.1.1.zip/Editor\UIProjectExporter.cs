using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace MrMak.UIImport
{
    // This exporter reads controls and resource references. It never invokes game callbacks.
    public static class UIProjectExporter
    {
        public static string LastResult { get; private set; } = "";
        public static string LastError { get; private set; } = "";
        static bool running;
        public static string ExportFolder => Path.GetFullPath(Path.Combine(Application.dataPath,"../.local/game-ui-export"));
        public static string Hash(byte[] bytes) { using(var hash=SHA256.Create())return string.Concat(hash.ComputeHash(bytes).Select(b=>b.ToString("x2"))); }
        public static string Key(string value)=>Hash(Encoding.UTF8.GetBytes(value));
        static float Finite(float value,float fallback=0)=>float.IsNaN(value)||float.IsInfinity(value)?fallback:value;
        static float Bound(float value,float min,float max)=>Mathf.Clamp(Finite(value),min,max);
        static string Color(Color c)=>"#"+ColorUtility.ToHtmlStringRGBA(c);
        static string Name(string value,int max=80)=>new string((value??"").Where(c=>!char.IsControl(c)).Take(max).ToArray());
        static JObject Presentation()=>new JObject{["horizontal"]="center",["vertical"]="center",["wrap"]=true,["opacity"]=1,["borderColor"]="#00000000",["borderWidth"]=0,["bold"]=false,["italic"]=false,["clip"]=false};
        static string ObjectPath(Transform value)=>value.parent==null?value.name:ObjectPath(value.parent)+"/"+value.name+"#"+value.GetSiblingIndex();
        static string PersistentKey(UnityEngine.Object value){var id=GlobalObjectId.GetGlobalObjectIdSlow(value);return id.targetObjectId==0?null:id.ToString();}
        internal static void SafeProjectPath(string path){var root=Path.GetFullPath(Path.Combine(Application.dataPath,".."));var target=Path.GetFullPath(path);if(!target.StartsWith(root+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new IOException("Export path left the game project.");for(var cursor=target;cursor.Length>root.Length;cursor=Path.GetDirectoryName(cursor))if((File.Exists(cursor)||Directory.Exists(cursor))&&(File.GetAttributes(cursor)&FileAttributes.ReparsePoint)!=0)throw new IOException("Export files/directories cannot redirect.");}
        static JObject Node(string id,string name,string parent,string type,Rect rect)=>new JObject {
            ["id"]=id,["name"]=Name(name,100),["parentId"]=parent==null?JValue.CreateNull():new JValue(parent),["type"]=type,
            ["rect"]=new JObject{["x"]=Bound(rect.x,-16384,16384),["y"]=Bound(rect.y,-16384,16384),["width"]=Bound(rect.width,0,16384),["height"]=Bound(rect.height,0,16384)},
            ["anchors"]=new JObject{["left"]=0,["top"]=0,["right"]=0,["bottom"]=0},["layout"]=new JObject{["mode"]="free",["gap"]=0,["padding"]=0},
            ["style"]=new JObject{["presentation"]=Presentation(),["background"]="",["color"]="#FFFFFFFF",["fontSize"]=24,["fontAssetId"]="",["assetId"]="",["crop"]=new JObject{["x"]=0,["y"]=0,["width"]=1,["height"]=1},["borderRadius"]=0,["slice"]=new JObject{["top"]=0,["right"]=0,["bottom"]=0,["left"]=0}},
            ["text"]="",["componentId"]="",["overrides"]=new JArray()
        };
        static JObject HitNode(string id,string name,string parent,Rect rect){var n=Node(id,name,parent,"button",rect);n["style"]["presentation"]=new JObject{["horizontal"]="center",["vertical"]="center",["wrap"]=false,["opacity"]=0,["borderColor"]="#00000000",["borderWidth"]=0,["bold"]=false,["italic"]=false,["clip"]=false};return n;}
        sealed class Capture
        {
            public readonly JObject Document;
            public readonly JArray Nodes=new JArray(),Origins=new JArray(),Assets=new JArray();
            public readonly Dictionary<VisualElement,string> Elements=new Dictionary<VisualElement,string>();
            readonly string folder;
            readonly HashSet<string> assets=new HashSet<string>();
            readonly Dictionary<Texture,string> textures=new Dictionary<Texture,string>();
            public Capture(string folder,string name,float width,float height) {
                this.folder=folder;
                Document=new JObject{["schemaVersion"]=4,["projectId"]="unity-export",["name"]=Name(name),["canvas"]=new JObject{["width"]=Bound(width,64,16384),["height"]=Bound(height,64,16384)},["referenceAssetId"]="",["nodes"]=Nodes,["assets"]=Assets,["components"]=new JArray(),["guides"]=new JArray(),["nativeBlocks"]=new JArray(),["behavior"]=new JObject{["version"]=1,["catalog"]=JObject.Parse("{\"version\":1,\"game\":\"Unity\",\"fields\":[{\"id\":\"ui.state\",\"type\":\"string\",\"en\":\"Authored UI state\",\"pt\":\"Estado da interface\",\"source\":\"Behavior runtime state\",\"owner\":\"Game UI Editor\"}],\"collections\":[],\"itemFields\":[],\"actions\":[]}"),["states"]=new JArray(new JObject{["id"]="Playing",["name"]="Playing"}),["initialState"]="Playing",["variables"]=new JArray(),["bindings"]=new JArray(),["rules"]=new JArray()}};
            }
            public void Origin(string id,string key,List<string> notes) { Origins.Add(new JObject{["nodeId"]=id,["key"]=key.Length>500?Key(key):key,["coverage"]=notes.Count==0?"editable":"partial",["notes"]=new JArray(notes.Distinct().Take(20))}); }
            public void Status(string id,bool visible,bool enabled){if(visible&&enabled)return;var condition=new JObject{["mode"]="all",["items"]=new JArray()};var binding=new JObject{["target"]=new JObject{["kind"]="node",["id"]=id},["text"]=null,["tooltip"]=null,["progress"]=null,["repeat"]=null,["visible"]=condition.DeepClone(),["enabled"]=condition.DeepClone()};foreach(var slot in new[]{"visible","enabled"})if(slot=="visible"?!visible:!enabled)((JArray)binding[slot]["items"]).Add(new JObject{["left"]=new JObject{["type"]="literal",["value"]=false},["op"]="eq",["right"]=new JObject{["type"]="literal",["value"]=true}});((JArray)Document["behavior"]["bindings"]).Add(binding);}
            public string Asset(byte[] data,string name,string mime,string kind,int width=0,int height=0) {
                if(data.Length>16*1024*1024)throw new InvalidOperationException("Asset exceeds the import budget: "+name);
                var id=Hash(data);if(!assets.Add(id))return id;
                var file=Path.Combine(folder,"assets",id+".asset");SafeProjectPath(file);Directory.CreateDirectory(Path.GetDirectoryName(file));SafeProjectPath(file);
                if(File.Exists(file)){if(Hash(File.ReadAllBytes(file))!=id)throw new IOException("Existing export asset is corrupt.");}else File.WriteAllBytes(file,data);
                var a=new JObject{["id"]=id,["name"]=Name(name,160),["kind"]=kind,["mime"]=mime};if(kind=="image"){a["width"]=width;a["height"]=height;}Assets.Add(a);return id;
            }
            public string Texture(Texture texture,List<string> notes) {
                if(texture==null)return "";
                if(textures.TryGetValue(texture,out var cached))return cached;
                var original=AssetDatabase.GetAssetPath(texture);var extension=Path.GetExtension(original).ToLowerInvariant();
                if((extension==".png"||extension==".jpg"||extension==".jpeg")&&File.Exists(original)){
                    var info=new FileInfo(original);if(info.Length<=8*1024*1024&&AssetImporter.GetAtPath(original) is TextureImporter importer){importer.GetSourceTextureWidthAndHeight(out var width,out var height);if(width>0&&width<=8192&&height>0&&height<=8192){var originalId=Asset(File.ReadAllBytes(original),Path.GetFileName(original),extension==".png"?"image/png":"image/jpeg","image",width,height);textures[texture]=originalId;return originalId;}}
                }
                if(texture.width>8192||texture.height>8192){notes.Add("Texture exceeds portable dimensions.");return "";}
                var previous=RenderTexture.active;var rt=RenderTexture.GetTemporary(texture.width,texture.height,0,RenderTextureFormat.ARGB32,RenderTextureReadWrite.sRGB);Texture2D copy=null;
                try{Graphics.Blit(texture,rt);RenderTexture.active=rt;copy=new Texture2D(texture.width,texture.height,TextureFormat.RGBA32,false);copy.ReadPixels(new Rect(0,0,texture.width,texture.height),0,0);copy.Apply();var bytes=copy.EncodeToPNG();if(bytes.Length>8*1024*1024){notes.Add("Encoded image exceeds 8 MB; resource needs an adapter.");return "";}return Asset(bytes,texture.name+".png","image/png","image",copy.width,copy.height);}
                finally{RenderTexture.active=previous;RenderTexture.ReleaseTemporary(rt);if(copy!=null)UnityEngine.Object.DestroyImmediate(copy);}
            }
            public string Font(UnityEngine.Object font,List<string> notes) {
                if(font==null)return "";var p=AssetDatabase.GetAssetPath(font);
                if(!(p.EndsWith(".ttf",StringComparison.OrdinalIgnoreCase)||p.EndsWith(".otf",StringComparison.OrdinalIgnoreCase))){notes.Add("Font source is embedded or generated; original font is not portable.");return "";}
                return Asset(File.ReadAllBytes(p),Path.GetFileName(p),p.EndsWith(".otf",StringComparison.OrdinalIgnoreCase)?"font/otf":"font/ttf","font");
            }
        }
        static void Source(JObject entry,string kind,string assetPath){var guid=AssetDatabase.AssetPathToGUID(assetPath);if(guid.Length==32&&File.Exists(assetPath))entry["source"]=new JObject{["kind"]=kind,["guid"]=guid,["sha256"]=Hash(File.ReadAllBytes(assetPath))};}
        static JObject Entry(string id,string name,string system,Capture capture)=>new JObject{["id"]=Key(id),["name"]=Name(name),["system"]=system,["document"]=capture.Document,["origins"]=capture.Origins};
        public static JObject CaptureToolkit(VisualElement root,string identity,string name,string folder,Action<JObject,Dictionary<VisualElement,string>> configure=null) {
            if(root.panel==null||root.layout.width<=0||root.layout.height<=0)throw new InvalidOperationException("Wait for the real UI Toolkit layout: "+name);
            var c=new Capture(folder,name,root.layout.width,root.layout.height);
            Toolkit(c,root,null,"root",root.worldBound.position);
            var entry=Entry(identity,name,"uitoolkit",c);configure?.Invoke(entry,c.Elements);return entry;
        }
        static void Toolkit(Capture c,VisualElement e,string parent,string key,Vector2 parentPosition) {
            if(c.Nodes.Count>=1900)throw new InvalidOperationException("UI screen exceeds 1900 controls. Export smaller roots.");
            var notes=new List<string>();var id="u-"+Key(key).Substring(0,32);var isText=e is TextElement;var type=e is Button||isText&&e.userData is Delegate?"button":isText?"text":"container";c.Elements[e]=id;
            var bounds=e.worldBound;var n=Node(id,string.IsNullOrEmpty(e.name)?(e is TextElement label&&!string.IsNullOrEmpty(label.text)?Name(label.text,80):e.GetType().Name):e.name,parent,type,new Rect(bounds.position-parentPosition,bounds.size));
            if(parent==null){n["rect"]["x"]=0;n["rect"]["y"]=0;}
            var s=e.resolvedStyle;var style=n["style"];style["background"]=Color(s.backgroundColor);style["color"]=Color(s.color);style["fontSize"]=Bound(s.fontSize,1,256);style["borderRadius"]=Bound(s.borderTopLeftRadius,0,2048);
            var align=s.unityTextAlign.ToString();var weight=s.unityFontStyleAndWeight.ToString();style["presentation"]=new JObject{["horizontal"]=align.EndsWith("Left")?"left":align.EndsWith("Right")?"right":"center",["vertical"]=align.StartsWith("Upper")?"top":align.StartsWith("Lower")?"bottom":"center",["wrap"]=s.whiteSpace==WhiteSpace.Normal,["opacity"]=parent==null?1:Bound(s.opacity,0,1),["borderWidth"]=Bound(Mathf.Max(s.borderTopWidth,s.borderLeftWidth,s.borderRightWidth,s.borderBottomWidth),0,100),["borderColor"]=Color(s.borderTopColor),["bold"]=weight.Contains("Bold"),["italic"]=weight.Contains("Italic"),["clip"]=e.style.overflow.value==Overflow.Hidden||e is ScrollView};
            if(isText)n["text"]=((TextElement)e).text?.Substring(0,Math.Min(4096,((TextElement)e).text.Length))??"";
            var image=s.backgroundImage;Texture texture=image.texture;Sprite sprite=image.sprite;
            if(e is Image im){if(im.image!=null)texture=im.image;if(im.sprite!=null)sprite=im.sprite;}
            if(sprite!=null)texture=sprite.texture;
            var asset=c.Texture(texture,notes);style["assetId"]=asset;
            if(asset!="")style["slice"]=new JObject{["left"]=Bound(s.unitySliceLeft,0,8192),["right"]=Bound(s.unitySliceRight,0,8192),["top"]=Bound(s.unitySliceTop,0,8192),["bottom"]=Bound(s.unitySliceBottom,0,8192)};
            if(sprite!=null&&asset!="") {try{var r=sprite.textureRect;style["crop"]=new JObject{["x"]=r.x/texture.width,["y"]=1-r.yMax/texture.height,["width"]=r.width/texture.width,["height"]=r.height/texture.height};var b=sprite.border;style["slice"]=new JObject{["left"]=b.x,["bottom"]=b.y,["right"]=b.z,["top"]=b.w};}catch{notes.Add("Packed/rotated sprite needs a dedicated atlas adapter.");}}
            if(image.vectorImage!=null)notes.Add("VectorImage requires a native/vector renderer.");
            if(asset!=""&&s.unityBackgroundImageTintColor!=UnityEngine.Color.white)notes.Add("Background image tint needs a material/tint renderer; original image retained.");
            if(asset!=""&&(s.backgroundSize.sizeType==BackgroundSizeType.Cover||s.backgroundSize.sizeType==BackgroundSizeType.Contain))notes.Add("Source background cover/contain uses portable stretch; verify image framing.");
            if(isText&&((TextElement)e).enableRichText&&((TextElement)e).text?.Contains("<")==true)notes.Add("Rich text source retained as text; inline markup needs a rich-text renderer.");
            if(s.unityFontDefinition.font!=null)style["fontAssetId"]=c.Font(s.unityFontDefinition.font,notes);
            else if(s.unityFontDefinition.fontAsset!=null)style["fontAssetId"]=c.Font(s.unityFontDefinition.fontAsset.sourceFontFile,notes);
            if(s.display==DisplayStyle.None)notes.Add("Inactive element: computed geometry may require a state profile.");
            if(e is ScrollView)notes.Add("Scroll viewport and clipping are preserved as source provenance; portable scrolling needs support.");
            if(s.borderLeftWidth!=s.borderRightWidth||s.borderTopWidth!=s.borderBottomWidth||s.borderLeftWidth!=s.borderTopWidth)notes.Add("Asymmetric borders use the largest source border width.");
            if(!(e is TextElement)&&s.flexDirection!=FlexDirection.Row&&s.flexDirection!=FlexDirection.Column)notes.Add("Unsupported flex direction.");
            notes.Add("Computed layout snapshot; responsive flex constraints need source mapping.");
            if(string.IsNullOrEmpty(e.viewDataKey)&&string.IsNullOrEmpty(e.name))notes.Add("Generated identity: keep sibling classes/order stable or assign viewDataKey.");
            if(type!="container"&&e.hierarchy.childCount>0)notes.Add("Custom children of a text/button control need an adapter.");c.Nodes.Add(n);c.Origin(id,key,notes);c.Status(id,s.display!=DisplayStyle.None&&s.visibility!=Visibility.Hidden,e.enabledSelf);
            if(type!="container")return;
            var counts=new Dictionary<string,int>();foreach(var child in e.hierarchy.Children()){
                var stem=!string.IsNullOrEmpty(child.viewDataKey)?"key="+child.viewDataKey:!string.IsNullOrEmpty(child.name)?"name="+child.name:child.GetType().Name+"."+string.Join(".",child.GetClasses().OrderBy(v=>v,StringComparer.Ordinal));
                counts.TryGetValue(stem,out var count);counts[stem]=count+1;var childKey=!string.IsNullOrEmpty(child.viewDataKey)?"viewDataKey:"+child.viewDataKey:key+"/"+stem+"#"+count;if(c.Elements.Values.Contains("u-"+Key(childKey).Substring(0,32)))throw new InvalidOperationException("Duplicate persistent viewDataKey in UI root: "+child.viewDataKey);Toolkit(c,child,id,childKey,bounds.position);
            }
            if(e.userData is Delegate||e.ClassListContains("ge-cell")){var caption=e.Children().OfType<TextElement>().FirstOrDefault(v=>!string.IsNullOrEmpty(v.text))?.text;var hit=HitNode(id+"-click",string.IsNullOrEmpty(caption)?(string)n["name"]+" click":caption,id,new Rect(0,0,bounds.width,bounds.height));c.Nodes.Add(hit);c.Origin((string)hit["id"],key+"/interaction",new List<string>{"Source interaction overlay; visual container and children remain editable."});}
        }
        public static JObject CaptureUGUI(RectTransform root,string identity,string name,string folder) {
            var c=new Capture(folder,name,root.rect.width,root.rect.height);UGUI(c,root,null,"root",root);return Entry(identity,name,"ugui",c);
        }
        static void UGUI(Capture c,RectTransform t,string parent,string key,RectTransform root) {
            if(c.Nodes.Count>=1900)throw new InvalidOperationException("uGUI tree exceeds its control budget.");
            var notes=new List<string>();var id="u-"+Key(key).Substring(0,32);var corners=new Vector3[4];t.GetWorldCorners(corners);for(var i=0;i<4;i++)corners[i]=root.InverseTransformPoint(corners[i]);
            var pos=new Vector2(corners[0].x-root.rect.xMin,root.rect.yMax-corners[1].y);var size=new Vector2(corners[2].x-corners[0].x,corners[1].y-corners[0].y);
            if(t!=root&&t.parent is RectTransform p){var pc=new Vector3[4];p.GetWorldCorners(pc);var pp=root.InverseTransformPoint(pc[1]);pos-=new Vector2(pp.x-root.rect.xMin,root.rect.yMax-pp.y);}
            var components=t.GetComponents<Component>().Where(x=>x!=null).ToArray();var text=components.FirstOrDefault(x=>x.GetType().FullName=="UnityEngine.UI.Text"||x.GetType().FullName=="TMPro.TextMeshProUGUI");var button=components.FirstOrDefault(x=>x.GetType().FullName=="UnityEngine.UI.Button");
            var type=t.childCount>0?"container":button!=null?"button":text!=null?"text":"container";var n=Node(id,t.name,parent,type,new Rect(pos,size));if(parent==null){n["rect"]["x"]=0;n["rect"]["y"]=0;}
            if(t!=root&&t.parent is RectTransform parentRect&&t.localRotation==Quaternion.identity&&t.localScale==Vector3.one){
                var left=t.anchorMin.x;var top=1-t.anchorMax.y;var right=t.anchorMax.x;var bottom=1-t.anchorMin.y;var rightOffset=pos.x+size.x-parentRect.rect.width*right;var bottomOffset=pos.y+size.y-parentRect.rect.height*bottom;
                // The portable rectangle stores an end offset when anchors stretch.
                // Negative end offsets cannot be represented by schema 4: keep the measured box.
                if((left==right||rightOffset>=0)&&(top==bottom||bottomOffset>=0)){n["anchors"]=new JObject{["left"]=left,["top"]=top,["right"]=right,["bottom"]=bottom};n["rect"]=new JObject{["x"]=pos.x-parentRect.rect.width*left,["y"]=pos.y-parentRect.rect.height*top,["width"]=left==right?size.x:rightOffset,["height"]=top==bottom?size.y:bottomOffset};}
                else notes.Add("Inset stretch offsets exceed the portable rectangle model; measured geometry retained.");
            }else if(t!=root)notes.Add("Rotated/scaled uGUI transform uses an axis-aligned measured box.");
            if(text!=null){var so=new SerializedObject(text);var value=so.FindProperty("m_Text")??so.FindProperty("m_text");n["text"]=value?.stringValue??"";var fontData=so.FindProperty("m_FontData");var font=fontData?.FindPropertyRelative("m_Font")?.objectReferenceValue;var tmp=so.FindProperty("m_fontAsset")?.objectReferenceValue;if(font==null&&tmp!=null){var tmpSo=new SerializedObject(tmp);font=tmpSo.FindProperty("m_SourceFontFile")?.objectReferenceValue;}n["style"]["fontAssetId"]=c.Font(font,notes);var fs=fontData?.FindPropertyRelative("m_FontSize")??so.FindProperty("m_fontSize");if(fs!=null)n["style"]["fontSize"]=Bound(fs.propertyType==SerializedPropertyType.Integer?fs.intValue:fs.floatValue,1,256);var color=so.FindProperty("m_Color")??so.FindProperty("m_fontColor");if(color!=null)n["style"]["color"]=Color(color.colorValue);var alignment=fontData?.FindPropertyRelative("m_Alignment")?.intValue??4;var weight=fontData?.FindPropertyRelative("m_FontStyle")?.intValue??0;n["style"]["presentation"]=new JObject{["horizontal"]=alignment%3==0?"left":alignment%3==2?"right":"center",["vertical"]=alignment<3?"top":alignment<6?"center":"bottom",["wrap"]=true,["opacity"]=1,["borderColor"]="#00000000",["borderWidth"]=0,["bold"]=(weight&1)!=0,["italic"]=(weight&2)!=0,["clip"]=false};if(tmp!=null)notes.Add("TMP alignment/rich-text features require visual review.");}
            var image=components.FirstOrDefault(x=>x.GetType().FullName=="UnityEngine.UI.Image"||x.GetType().FullName=="UnityEngine.UI.RawImage");
            if(image!=null){var so=new SerializedObject(image);var sprite=so.FindProperty("m_Sprite")?.objectReferenceValue as Sprite;var texture=sprite!=null?sprite.texture:so.FindProperty("m_Texture")?.objectReferenceValue as Texture;var asset=c.Texture(texture,notes);n["style"]["assetId"]=asset;if(sprite!=null&&asset!=""){try{var r=sprite.textureRect;n["style"]["crop"]=new JObject{["x"]=r.x/texture.width,["y"]=1-r.yMax/texture.height,["width"]=r.width/texture.width,["height"]=r.height/texture.height};var b=sprite.border;n["style"]["slice"]=new JObject{["left"]=b.x,["bottom"]=b.y,["right"]=b.z,["top"]=b.w};}catch{notes.Add("Packed sprite requires an atlas adapter.");}}}
            if(components.Any(x=>x.GetType().Name.Contains("Mask")||x.GetType().Name.Contains("Scroll")))notes.Add("Mask/scroll behavior needs a portable renderer.");
            if(!t.gameObject.activeInHierarchy)notes.Add("Inactive source control: verify with a state profile.");
            if(components.Any(x=>x.GetType().Name.Contains("Layout")))notes.Add("uGUI layout group uses measured geometry; responsive layout needs mapping.");
            if(button!=null){var calls=new SerializedObject(button).FindProperty("m_OnClick.m_PersistentCalls.m_Calls");if(calls!=null)for(var i=0;i<calls.arraySize;i++)notes.Add("Unmapped serialized callback: "+calls.GetArrayElementAtIndex(i).FindPropertyRelative("m_MethodName").stringValue);}
            var group=t.GetComponent<CanvasGroup>();if(group!=null)n["style"]["presentation"]["opacity"]=Bound(group.alpha,0,1);c.Nodes.Add(n);c.Origin(id,key,notes);c.Status(id,t.gameObject.activeSelf,(group==null||group.interactable)&&(button==null||new SerializedObject(button).FindProperty("m_Interactable")?.boolValue!=false));
            if(button!=null&&type=="container"){var hit=HitNode(id+"-click",t.name+" click",id,new Rect(0,0,size.x,size.y));c.Nodes.Add(hit);c.Origin((string)hit["id"],key+"/click",new List<string>{"Button interaction overlay; source transform is shared with its visual container."});}
            var names=new Dictionary<string,int>();foreach(Transform child in t){if(!(child is RectTransform rect))continue;names.TryGetValue(child.name,out var index);names[child.name]=index+1;var childKey=PersistentKey(child);UGUI(c,rect,id,childKey??key+"/"+child.name+"#"+index,root);}
        }
        [MenuItem("Tools/Game UI Editor/Export Existing UI")]
        public static async void ExportMenu() {try{await ExportCurrent();EditorUtility.DisplayDialog("Game UI Editor",LastResult,"OK");}catch(Exception e){Debug.LogException(e);EditorUtility.DisplayDialog("UI export failed",e.Message,"OK");}}
        public static async Task ExportCurrent(bool includeProjectAssets=true) {
            if(running)throw new InvalidOperationException("A UI export is already running.");running=true;LastResult="";LastError="";ExportPreviewWindow host=null;
            try{
                var folder=ExportFolder;SafeProjectPath(folder);Directory.CreateDirectory(folder);if(new DirectoryInfo(folder).Attributes.HasFlag(FileAttributes.ReparsePoint))throw new IOException("Export folder cannot redirect.");
                var diagnostics=new JArray();Action<string> report=message=>{if(diagnostics.Count<128)diagnostics.Add(Name(message,500));};var entries=new JArray();var documents=Resources.FindObjectsOfTypeAll<UIDocument>().Where(d=>d.gameObject.scene.IsValid()&&d.rootVisualElement?.panel!=null).OrderBy(d=>d.gameObject.scene.path+"/"+d.name,StringComparer.Ordinal).ToArray();
                foreach(var doc in documents){var identity=doc.gameObject.scene.path+"/"+ObjectPath(doc.transform);
                    if(GEImportProfiles.IsGE(doc)){
                        foreach(var profile in GEImportProfiles.Build(doc,report))try{await NextFrame();await NextFrame();var entry=CaptureToolkit(profile.Root,"ge-profile:"+profile.Id,profile.Name,folder,profile.Configure);((JObject)entry["document"]["behavior"]).Remove("catalog");var links=new JArray();foreach(var n in (JArray)entry["document"]["nodes"]){if((string)n["type"]!="button")continue;var label=(string)n["text"];if(string.IsNullOrEmpty(label))label=(string)n["name"];string target=null;if((string)n["name"]=="pausa click"||label=="Pausa")target="ge.pause";else if(label=="Continuar"||label=="Nova partida contra a IA")target="ge.hud";else if(label=="Opções")target=profile.Id.StartsWith("ge.pause")?"ge.pause-options":"ge.start-options";else if(label=="Voltar")target=profile.Id.StartsWith("ge.pause")?"ge.pause":"ge.start";if(target!=null)links.Add(new JObject{["nodeId"]=(string)n["id"],["target"]=Key("ge-profile:"+target)});}entry["links"]=links;if(profile.Id!="ge.hud")((JArray)entry["origins"][0]["notes"]).Add("Declared GE screen profile; game callbacks were not invoked. Dynamic/final-result data uses the current match.");entries.Add(entry);}finally{profile.Dispose();}
                    }else entries.Add(CaptureToolkit(doc.rootVisualElement,identity,doc.name,folder));}
                foreach(var canvas in Resources.FindObjectsOfTypeAll<Canvas>().Where(c=>c.isRootCanvas&&c.gameObject.scene.IsValid()).OrderBy(c=>c.name,StringComparer.Ordinal)){var entry=CaptureUGUI((RectTransform)canvas.transform,PersistentKey(canvas)??canvas.gameObject.scene.path+"/"+ObjectPath(canvas.transform),canvas.name,folder);Source(entry,"scene",canvas.gameObject.scene.path);entries.Add(entry);}
                if(includeProjectAssets){host=ScriptableObject.CreateInstance<ExportPreviewWindow>();host.ShowUtility();host.position=new Rect(80,80,1920,1080);
                    foreach(var guid in AssetDatabase.FindAssets("t:VisualTreeAsset",new[]{"Assets"}).OrderBy(v=>v,StringComparer.Ordinal).Take(33)){var assetPath=AssetDatabase.GUIDToAssetPath(guid);if(!assetPath.StartsWith("Assets/",StringComparison.Ordinal))continue;if(entries.Count>=64){report("Additional UXML assets omitted at 64 UI roots. Export the selected scene separately.");break;}host.rootVisualElement.Clear();var tree=AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(assetPath);tree.CloneTree(host.rootVisualElement);await NextFrame();await NextFrame();var entry=CaptureToolkit(host.rootVisualElement,"uxml:"+guid,Path.GetFileNameWithoutExtension(assetPath),folder);Source(entry,"uxml",assetPath);entries.Add(entry);}
                }
                if(includeProjectAssets){
                    var prefabs=AssetDatabase.FindAssets("t:Prefab",new[]{"Assets"}).OrderBy(v=>v,StringComparer.Ordinal).ToArray();var examined=0;
                    foreach(var guid in prefabs){
                        if(++examined>128||entries.Count>=64){report("Prefab inventory budget reached. Open the required prefab/scene and export separately.");break;}
                        var assetPath=AssetDatabase.GUIDToAssetPath(guid);var asset=AssetDatabase.LoadAssetAtPath<GameObject>(assetPath);if(asset==null||asset.GetComponentsInChildren<Canvas>(true).Length==0)continue;
                        GameObject contents=null;
                        try{contents=PrefabUtility.LoadPrefabContents(assetPath);Canvas.ForceUpdateCanvases();foreach(var canvas in contents.GetComponentsInChildren<Canvas>(true).Where(c=>c.isRootCanvas)){var entry=CaptureUGUI((RectTransform)canvas.transform,"prefab:"+guid+"/"+ObjectPath(canvas.transform),"Prefab - "+Path.GetFileNameWithoutExtension(assetPath),folder);Source(entry,"prefab",assetPath);((JArray)entry["origins"][0]["notes"]).Add("Prefab inspected without entering Play; computed layout needs scene context review.");entries.Add(entry);}}
                        catch(Exception e){report("Prefab not observed: "+assetPath+" - "+e.GetBaseException().Message);}
                        finally{if(contents!=null)PrefabUtility.UnloadPrefabContents(contents);}
                    }
                    var loaded=new HashSet<string>();for(var i=0;i<UnityEngine.SceneManagement.SceneManager.sceneCount;i++)loaded.Add(UnityEngine.SceneManagement.SceneManager.GetSceneAt(i).path);
                    var unseen=AssetDatabase.FindAssets("t:Scene",new[]{"Assets"}).Count(g=>!loaded.Contains(AssetDatabase.GUIDToAssetPath(g)));if(unseen>0)report(unseen+" unloaded scene(s) were not exercised. Open each required scene and export its UI; code-built screens need declared profiles.");
                }
                if(entries.Count==0)throw new InvalidOperationException("No existing UI found. Open a scene/prefab or enter Play for procedural UI.");if(entries.Count>64)throw new InvalidOperationException("Export exceeds 64 UI roots.");
                var present=new HashSet<string>(entries.Select(e=>(string)e["id"]));foreach(var entry in entries){if(entry["links"] is JArray links)foreach(var link in links.ToArray())if(!present.Contains((string)link["target"]))link.Remove();foreach(var node in (JArray)entry["document"]["nodes"]){if((string)node["type"]!="button")continue;var id=(string)node["id"];if(((JArray)entry["document"]["behavior"]["rules"]).Any(r=>(string)r["target"]["id"]==id)||(entry["links"] is JArray nav&&nav.Any(l=>(string)l["nodeId"]==id)))continue;var origin=((JArray)entry["origins"]).First(o=>(string)o["nodeId"]==id);origin["coverage"]="unmapped";((JArray)origin["notes"]).Add("Source interaction requires a reviewed behavior mapping.");}}
                var manifest=new JObject{["version"]=1,["sourceId"]=Key(PlayerSettings.productGUID.ToString()),["sourceName"]=Name(Application.productName),["entries"]=entries,["diagnostics"]=diagnostics};
                var file=Path.Combine(folder,"manifest.json");var temp=file+"."+Guid.NewGuid().ToString("N")+".tmp";SafeProjectPath(file);SafeProjectPath(temp);File.WriteAllText(temp,manifest.ToString(Formatting.None),new UTF8Encoding(false));if(File.Exists(file))File.Replace(temp,file,null);else File.Move(temp,file);LastResult="Exported "+entries.Count+" UI roots to "+folder;Debug.Log(LastResult);
            }catch(Exception e){LastError=e.GetBaseException().Message;throw;}finally{if(host!=null)host.Close();running=false;}
        }
        static Task NextFrame(){var completion=new TaskCompletionSource<bool>();EditorApplication.delayCall+=()=>completion.TrySetResult(true);return completion.Task;}
    }
    public sealed class ExportPreviewWindow:EditorWindow { }
}
